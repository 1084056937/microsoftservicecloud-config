package cn.zhz.commond.beans;

import java.io.Serializable;

public class Role implements Serializable {

    private Integer id;
    private String name;
    private String nameZh;
    private int qubie;

    public int getQubie() {
        return qubie;
    }

    public void setQubie(int qubie) {
        this.qubie = qubie;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameZh() {
        return nameZh;
    }

    public void setNameZh(String nameZh) {
        this.nameZh = nameZh;
    }
}
