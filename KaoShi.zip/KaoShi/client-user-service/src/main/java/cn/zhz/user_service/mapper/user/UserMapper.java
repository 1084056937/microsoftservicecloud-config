package cn.zhz.user_service.mapper.user;


import cn.zhz.commond.beans.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserMapper {

    User loadUserByUsername(@Param("username") String username);

    List<Role> getUserRoleByUId(@Param("id") Integer id);

    List<Menu> getAllMenu();

    List<User> getUserList();

}
