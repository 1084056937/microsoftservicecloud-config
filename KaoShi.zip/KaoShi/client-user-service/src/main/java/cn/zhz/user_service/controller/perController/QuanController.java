package cn.zhz.user_service.controller.perController;

import cn.zhz.commond.beans.*;
import cn.zhz.user_service.mapper.menu.MenuMapper;
import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
public class QuanController {

    @Resource
    MenuMapper menuMapper;

    @RequestMapping("/get/menuList")
    @ResponseBody
    public String getMenuList(@RequestParam("uid") int uid){
        List<Menu> list=menuMapper.getMenuListByUid(uid);
        String menuString1= JSON.toJSONString(list);
        return menuString1;
    }

    @RequestMapping("/not/get/menuList")
    @ResponseBody
    public String getNotMenuList(@RequestParam("uid") int uid){
        List<Menu> list=menuMapper.getMenuListNotByUid(uid);
        String menuString1= JSON.toJSONString(list);
        return menuString1;
    }

    @RequestMapping("/get/user/byid")
    @ResponseBody
    public String getUserById(@RequestParam("id") int id){
        User user =menuMapper.getUserById(id);
        String menuString1= JSON.toJSONString(user);
        return menuString1;
    }

    @RequestMapping("/getRoleIdByUid")
    @ResponseBody
    public String getRoleIdByUid(@RequestParam("uid") int uid){
        Integer rid =menuMapper.getRidByUid(uid);
        return rid.toString();
    }

    @RequestMapping("/addMenuByRidAndMid")
    @ResponseBody
    public String addMenuByRidAndMid(@RequestParam("rid") int rid, @RequestParam("mid") int mid){
        Integer jie =menuMapper.addMenuRoleByRidAndMid(rid,mid);
        return jie.toString();
    }

    @RequestMapping("/deleteMenuByRidAndMid")
    @ResponseBody
    public String deleteMenuByRidAndMid(@RequestParam("rid") int rid, @RequestParam("mid") int mid){
        Integer jie =menuMapper.deleteMenuRoleByRidAndMid(rid,mid);
        return jie.toString();
    }

}
