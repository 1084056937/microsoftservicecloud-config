package cn.zhz.user_service.mapper.per;


import cn.zhz.commond.beans.Menu;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PerMapper {

    /**
     * 查询所有菜单列表
     */
    List<Menu> getAllMenus();


}
