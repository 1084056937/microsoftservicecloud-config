package cn.zhz.user_service.mapper.menu;

import cn.zhz.commond.beans.Menu;
import cn.zhz.commond.beans.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MenuMapper {

    public List<Menu> getMenuListByUid(@Param("uid") int uid);

    public List<Menu> getMenuListNotByUid(@Param("uid") int uid);

    public User getUserById(@Param("id") int id);

    public int getRidByUid(@Param("uid") int uid);

    public int addMenuRoleByRidAndMid(@Param("rid") int rid, @Param("mid") int mid);

    public int deleteMenuRoleByRidAndMid(@Param("rid") int rid, @Param("mid") int mid);
}
