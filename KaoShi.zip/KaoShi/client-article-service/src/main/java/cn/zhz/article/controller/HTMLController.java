package cn.zhz.article.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 负责页面跳转的controller
 */
@Controller
@RequestMapping("/api/html")
public class HTMLController {
    @RequestMapping("/userIndex")
    public String userIndex() {
        return "userIndex";
    }

    @RequestMapping("/admin")
    public String xitongAdmin() {
        return "userAdmin";
    }
}
