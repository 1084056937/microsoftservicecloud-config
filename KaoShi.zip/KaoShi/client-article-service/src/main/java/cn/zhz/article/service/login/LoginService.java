package cn.zhz.article.service.login;

import cn.zhz.article.service.user.UserService;
import cn.zhz.commond.beans.Role;
import cn.zhz.commond.beans.User;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class LoginService implements UserDetailsService {
    @Resource
    UserService userService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //获取json数据转为user对象
        String userString = userService.loadUserByUsername(username);
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>" + userString);
        User user = JSON.parseObject(userString, new TypeReference<User>() {});
        if (user == null) {
            throw new UsernameNotFoundException("账户不存在");
        }
        String roleList = userService.getUserRoleByUId(user.getId());
        List<Role> list = JSON.parseObject(roleList, new TypeReference<List<Role>>() {
        });
        user.setRoles(list);
        return user;
    }
}
