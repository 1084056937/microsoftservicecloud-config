package cn.zhz.article.controller.per;

import cn.zhz.article.service.per.PerService;
import cn.zhz.article.service.user.UserService;
import cn.zhz.commond.beans.Menu;
import cn.zhz.commond.beans.User;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/api/per")
public class PerController {
    @Resource
    PerService perService;
    @Resource
    UserService userService;

    /**
     * 点击按钮进入权限分配页面
     * @param model
     * @return
     */
    @RequestMapping("/perIndex")
    public String userList(Model model) {
        String userString = userService.userList();
        List<User> list = JSON.parseObject(userString, new TypeReference<List<User>>() {
        });
        model.addAttribute("userList", list);
        return "per/perIndex";
    }

    /**
     * 权限分配页面
     *
     * @param uid
     * @param model
     * @return
     */
    @RequestMapping("/perList")
    public String quanFen(String uid, Model model) {

        String userString = perService.getUserById(Integer.parseInt(uid));
        User user = JSON.parseObject(userString, new TypeReference<User>() {
        });
        model.addAttribute("user", user);
        //获取json格式的数据
        String menu1 = perService.getMenuList(Integer.parseInt(uid));
        String menu2 = perService.getNotMenuList(Integer.parseInt(uid));
        //已拥有
        List<Menu> list1 = JSON.parseObject(menu1, new TypeReference<List<Menu>>() {
        });
        model.addAttribute("list1", list1);
        model.addAttribute("size1", list1.size());
        //未拥有
        List<Menu> list = JSON.parseObject(menu2, new TypeReference<List<Menu>>() {
        });
        model.addAttribute("list", list);
        model.addAttribute("size", list.size());
        return "per/perAddAndDel";
    }

    /**
     * 分配权限
     *
     * @param menuId
     * @param userId
     * @return
     */
    @RequestMapping("/fenPei")
    public String quan(@RequestParam(required = false) String[] menuId,
                       @RequestParam(required = false) String userId) {
        String qwe = perService.getRoleIdByUid(Integer.parseInt(userId));
        int rid = Integer.parseInt(qwe);

        for (int i = 0; i < menuId.length; i++) {
            perService.addMenuByRidAndMid(rid, Integer.parseInt(menuId[i]));
        }

        return "redirect:/api/per/perList";
    }

    /**
     * 取消权限
     *
     * @param menuId
     * @param userId
     * @return
     */
    @RequestMapping("/quXiao")
    public String quxiaoquan(@RequestParam(required = false) String[] menuId,
                             @RequestParam(required = false) String userId) {
        String qwe = perService.getRoleIdByUid(Integer.parseInt(userId));
        int rid = Integer.parseInt(qwe);
        for (int i = 0; i < menuId.length; i++) {
            perService.deleteMenuByRidAndMid(rid, Integer.parseInt(menuId[i]));
        }
        return "redirect:/api/per/perList";
    }
}
