package cn.zhz.article.service.user;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Service
@FeignClient(value = "EUREKA-CLIENT-USER-SERVICE")
public interface UserService {
    @RequestMapping("/getUserByUserName")
    String loadUserByUsername(@RequestParam("username") String username);

    @RequestMapping("/getUserRoleByUId")
    String getUserRoleByUId(@RequestParam("id") Integer id);

    @RequestMapping("/getAllMenu")
    String getAllMenu();

    @RequestMapping("/user/list")
    String userList();
}
