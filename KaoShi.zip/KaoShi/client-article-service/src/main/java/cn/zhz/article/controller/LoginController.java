package cn.zhz.article.controller;

import cn.zhz.commond.beans.User;
import com.alibaba.fastjson.JSON;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;

@Controller
public class LoginController {

    @Resource
    StringRedisTemplate stringRedisTemplate;
    @RequestMapping("/index")
    public String index() {
        User user =
                (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        ops.set("user", JSON.toJSONString(user));
        return "index";
    }
}
