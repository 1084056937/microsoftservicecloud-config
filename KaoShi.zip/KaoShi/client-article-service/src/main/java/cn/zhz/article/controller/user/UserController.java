package cn.zhz.article.controller.user;

import cn.zhz.article.service.user.UserService;
import cn.zhz.commond.beans.*;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("/api/user")
public class UserController {
    @Resource
    UserService userService;

    @RequestMapping("/selectUser")
    public String userAdmin(Model model) {
        String userString = userService.userList();
        System.out.println(userString);
        List<User> list = JSON.parseObject(userString, new TypeReference<List<User>>() {
        });
        System.out.println(list.toString());
        model.addAttribute("userList", list);
        return "userIndex";
    }

    /*@RequestMapping("/order/getUserByUserName")
    public String loadUserByUsername(@RequestParam("username") String username) {
        String user = userService.loadUserByUsername(username);
        return user;
    }



    @RequestMapping("/order/getUserRoleByUid")
    public String getUserRoleByUid(@RequestParam("id") Integer id) {
        String roleList = userService.getUserRoleByUId(id);
        return roleList;
    }

    @RequestMapping("/order/getAllMenu")
    public String getAllMenu() {
        String roleMenu = userService.getAllMenu();
        List<Menu> list = JSON.parseObject(roleMenu, new TypeReference<List<Menu>>() {
        });
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>" + list.get(0).getPattern());
        return roleMenu;
    }*/
}
