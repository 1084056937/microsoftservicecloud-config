package cn.zhz.article.service.per;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Service
@FeignClient(value = "EUREKA-CLIENT-USER-SERVICE")
public interface PerService {
    @RequestMapping("/get/menuList")
    String getMenuList(@RequestParam("uid") int uid);

    @RequestMapping("/not/get/menuList")
    String getNotMenuList(@RequestParam("uid") int uid);

    @RequestMapping("/get/user/byid")
    String getUserById(@RequestParam("id") int id);

    @RequestMapping("/getRoleIdByUid")
    String getRoleIdByUid(@RequestParam("uid") int uid);

    @RequestMapping("/addMenuByRidAndMid")
    String addMenuByRidAndMid(@RequestParam("rid") int rid, @RequestParam("mid") int mid);

    @RequestMapping("/deleteMenuByRidAndMid")
    String deleteMenuByRidAndMid(@RequestParam("rid") int rid, @RequestParam("mid") int mid);
}
