package cn.zhz.article;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class ClientArtileApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClientArtileApplication.class, args);
    }
}
