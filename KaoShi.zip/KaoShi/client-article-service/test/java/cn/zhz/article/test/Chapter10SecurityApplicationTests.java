package cn.zhz.article.test;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootTest
class Chapter10SecurityApplicationTests {

    @Test
    void contextLoads() {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(10);
        String pwd = encoder.encode("123456");
        System.out.println(pwd);
    }

}
